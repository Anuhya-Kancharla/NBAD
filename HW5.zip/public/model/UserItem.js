var UserItem = function(Item_Code, Rating, Tried_it){
  this.Item_Code = Item_Code;
  this.Rating = Rating;
  this.Tried_it = Tried_it;
};

module.exports = UserItem;
